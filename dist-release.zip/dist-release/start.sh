#!/bin/bash

# SPages 智能启动脚本
# 自动检测系统并下载对应的 Node.js 运行时

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NODE_VERSION="20.18.1"
RUNTIME_DIR="$SCRIPT_DIR/.runtime"
NODE_DIR="$RUNTIME_DIR/node"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "🚀 启动 SPages..."

# 检测系统架构
detect_platform() {
  OS=$(uname -s | tr '[:upper:]' '[:lower:]')
  ARCH=$(uname -m)

  case "$OS" in
    linux*)
      OS="linux"
      ;;
    darwin*)
      OS="darwin"
      ;;
    *)
      echo -e "${RED}❌ 不支持的操作系统: $OS${NC}"
      exit 1
      ;;
  esac

  case "$ARCH" in
    x86_64|amd64)
      ARCH="x64"
      ;;
    aarch64|arm64)
      ARCH="arm64"
      ;;
    *)
      echo -e "${RED}❌ 不支持的架构: $ARCH${NC}"
      exit 1
      ;;
  esac

  PLATFORM="${OS}-${ARCH}"
  echo -e "${GREEN}✓${NC} 检测到系统: $PLATFORM"
}

# 下载并安装 Node.js
install_nodejs() {
  if [ -f "$NODE_DIR/bin/node" ]; then
    INSTALLED_VERSION=$("$NODE_DIR/bin/node" --version 2>/dev/null | sed 's/v//')
    if [ "$INSTALLED_VERSION" = "$NODE_VERSION" ]; then
      echo -e "${GREEN}✓${NC} Node.js $NODE_VERSION 已安装"
      return
    else
      echo -e "${YELLOW}⚠${NC} 发现旧版本 Node.js ($INSTALLED_VERSION)，正在更新..."
      rm -rf "$RUNTIME_DIR"
    fi
  fi

  echo -e "${YELLOW}⬇${NC} 下载 Node.js $NODE_VERSION for $PLATFORM..."

  mkdir -p "$RUNTIME_DIR"
  cd "$RUNTIME_DIR"

  NODE_DIST="node-v${NODE_VERSION}-${PLATFORM}"
  NODE_URL="https://nodejs.org/dist/v${NODE_VERSION}/${NODE_DIST}.tar.gz"

  # 尝试使用 curl 或 wget 下载
  if command -v curl &> /dev/null; then
    curl -fSL "$NODE_URL" -o node.tar.gz
  elif command -v wget &> /dev/null; then
    wget -q "$NODE_URL" -O node.tar.gz
  else
    echo -e "${RED}❌ 需要 curl 或 wget 来下载 Node.js${NC}"
    exit 1
  fi

  echo -e "${YELLOW}📦${NC} 解压 Node.js..."
  tar -xzf node.tar.gz
  mv "${NODE_DIST}" node
  rm node.tar.gz

  echo -e "${GREEN}✓${NC} Node.js 安装完成"
}

# 安装依赖
install_dependencies() {
  if [ -d "$SCRIPT_DIR/node_modules" ]; then
    echo -e "${GREEN}✓${NC} 依赖已安装"
    return
  fi

  echo -e "${YELLOW}📦${NC} 安装项目依赖..."
  cd "$SCRIPT_DIR"
  # 设置 PATH 让 npm 能找到 node
  export PATH="$NODE_DIR/bin:$PATH"
  "$NODE_DIR/bin/npm" install --production --silent
  echo -e "${GREEN}✓${NC} 依赖安装完成"
}

# 启动应用
start_app() {
  echo -e "${GREEN}✓${NC} 启动 SPages 服务..."
  echo ""
  cd "$SCRIPT_DIR"
  export PATH="$NODE_DIR/bin:$PATH"
  export NODE_ENV=production
  "$NODE_DIR/bin/node" server/index.js
}

# 主流程
detect_platform
install_nodejs
install_dependencies
start_app
