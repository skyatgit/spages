#!/bin/bash
pkill -f "server/index.js"
echo "✓ SPages 已停止"
