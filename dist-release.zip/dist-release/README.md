# SPages - 自托管部署平台

## ✨ 特性

- ✅ **零依赖安装** - 无需预装 Node.js 环境
- ✅ **跨平台支持** - 支持 Linux、macOS、Windows
- ✅ **自动下载运行时** - 首次启动自动下载对应系统的 Node.js
- ✅ **开箱即用** - 解压即可运行

## 🚀 快速开始

### Linux / macOS

```bash
# 赋予执行权限
chmod +x start.sh stop.sh

# 启动服务
./start.sh

# 停止服务（另一个终端）
./stop.sh
```

### Windows

```cmd
:: 双击运行
start.bat

:: 或在命令行运行
start.bat

:: 停止服务
stop.bat
```

## 📦 首次启动

首次运行时，启动脚本会自动：

1. 检测系统和架构
2. 下载对应的 Node.js 20.18.1 运行时（约 30-50MB）
3. 安装项目依赖
4. 启动服务

所有文件都下载到 `.runtime` 目录，不会污染系统环境。

## 🌐 访问应用

默认地址: http://localhost:3000

## 📁 目录结构

```
spages/
├── .runtime/          # 自动创建，包含 Node.js 运行时
│   └── node/
├── server/            # 服务器代码
├── dist/              # 前端构建文件
├── node_modules/      # 自动安装的依赖
├── data/              # 运行时创建，存储项目数据
├── start.sh           # Linux/Mac 启动脚本
├── start.bat          # Windows 启动脚本
├── stop.sh            # Linux/Mac 停止脚本
└── stop.bat           # Windows 停止脚本
```

## 🔄 使用 PM2 管理（Linux/Mac 推荐）

如果你想让应用在后台运行并开机自启：

```bash
# 首次运行 start.sh 后，会在 .runtime/node/bin 下有 npm 和 node

# 安装 PM2
./.runtime/node/bin/npm install -g pm2

# 创建启动配置
cat > ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'spages',
    script: './server/index.js',
    cwd: __dirname,
    interpreter: './.runtime/node/bin/node',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    }
  }]
}
EOF

# 启动
./.runtime/node/bin/pm2 start ecosystem.config.cjs

# 保存配置
./.runtime/node/bin/pm2 save

# 开机自启
./.runtime/node/bin/pm2 startup

# 常用命令
./.runtime/node/bin/pm2 list          # 查看状态
./.runtime/node/bin/pm2 logs spages   # 查看日志
./.runtime/node/bin/pm2 restart spages # 重启
./.runtime/node/bin/pm2 stop spages    # 停止
```

## 🔧 systemd 服务（Linux）

创建 `/etc/systemd/system/spages.service`：

```ini
[Unit]
Description=SPages Deployment Platform
After=network.target

[Service]
Type=simple
User=your-user
WorkingDirectory=/path/to/spages
ExecStart=/path/to/spages/.runtime/node/bin/node server/index.js
Restart=on-failure
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

启动服务：

```bash
sudo systemctl daemon-reload
sudo systemctl enable spages
sudo systemctl start spages
sudo systemctl status spages
```

## 📝 环境变量

创建 `.env` 文件（可选）：

```env
PORT=3000
NODE_ENV=production
```

## 🔐 数据备份

重要数据存储在 `data/` 目录，包括：
- 项目配置
- 部署历史
- 日志文件

定期备份此目录即可。

## 🆙 更新部署

1. 备份 `data/` 目录
2. 下载新版本覆盖所有文件（保留 `data/` 目录）
3. 重启服务

## ⚠️ 注意事项

- 首次启动需要网络连接来下载 Node.js 运行时
- `.runtime` 目录大约占用 100MB 空间
- Windows 需要管理员权限来安装某些 npm 包

## 🐛 故障排除

### 端口被占用

修改 `.env` 文件中的 `PORT` 变量

### 启动失败

1. 检查 3000 端口是否被占用
2. 确保有网络连接（首次启动）
3. 检查 `data/` 目录权限

### 删除运行时重新下载

```bash
rm -rf .runtime node_modules
./start.sh
```

## 📞 技术支持

- GitHub: https://github.com/your-repo/spages
- Issues: https://github.com/your-repo/spages/issues

## 📄 许可证

MIT License
